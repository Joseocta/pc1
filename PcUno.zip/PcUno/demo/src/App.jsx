import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './App.css'; // Importa el archivo CSS personalizado


function App() {

    const [username, setUsername] = useState('');
    const [sign, setSign] = useState('')
    const [socket, setSocket] = useState(null);
    const [message, setMessage] = useState('');
    const [receivedMessages, setReceivedMessages] = useState([]);

    useEffect(() => {
        const newSocket = io(`http://localhost:3001`);
        setSocket(newSocket);

        newSocket.on('connect', () => {
            console.log('Conectado al servidor');
          });


        newSocket.on('messageFromServer', (msg) => {
            setReceivedMessages(prev => [...prev, msg]);
        });
        return () => newSocket.close();
    }, [setSocket]);

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
      };

      const handleJoinChat = () => {
        if (username) {
          socket.emit('joinChat', username);
          // Redirigir a la interfaz del chat
        } else {
          alert('Ingrese un nombre de usuario');
        }
      };
    const Contraseña = (e) => {
        setSign(e.target.value)
    };

    const sendMessage = () => {
        socket.emit('messageFromClient', message);
        setMessage('');
    };

    return (
        <div className="App">

        <div className="chat-container">
            <h1>Bienvenido al Chat</h1>
                <form onSubmit={(event) => event.preventDefault()}>
                    <div className="input-group">
                        <label htmlFor="username">Nombre de usuario:</label>

                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={handleUsernameChange}
                            placeholder="Ingresa tu nombre de usuario"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="username">Contraseña:</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={handleUsernameChange}
                            placeholder="Ingresa Contraseña"
                            required
                        />
                    </div>
                    <hr/>
                    <div>
                        <button onClick={handleJoinChat} className="btn">Unirse al chat</button>
                    </div>
                </form>
        </div>


            <input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Send a message..."
            />
            <button onClick={sendMessage}>Send</button>
            <div>
                {receivedMessages.map((msg, index) => (
                    <p key={index}>{msg.data}</p>
                ))}
            </div>
        </div>
    );
}
export default App;
